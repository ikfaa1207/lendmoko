<?php include '../V/include/header.php'; ?>
<h2><span class="dashicons dashicons-welcome-add-page">Welcome</span></h2>
<?php include '../V/include/footer.php'; ?>