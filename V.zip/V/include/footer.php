</body>
<footer style="position: fixed; bottom: 0; width: 100%; text-align: center;">
    <p class="text-muted">&copy; <?php echo date("Y"); ?> <strong>Lendmoco</strong></p>
</footer>

</html>