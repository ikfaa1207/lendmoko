rootfolder/admin/login.php
../login.php

rootfolder/admin1
rootfolder/admin2
use a specific location ../admin1/login.php

header('Location: ' . $_SERVER['HTTP_REFERER']);




// Start a new session or resume the existing one
session_start();

// Store user data in session variables
$_SESSION['username'] = $user['username'];
$_SESSION['logged_in'] = time();

<main id="content">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <button type="button" id="sidebarCollapse" class="btn btn-info">
                <i class="fas fa-align-left"></i>
                <span>Toggle Sidebar</span>
            </button>
        </div>
    </nav>

    <!-- Your content goes here -->
</main>





<?php
// Start session
session_start();

// Include your database connection file
require_once 'db_connection.php';

// Check if user is logged in (session verification)
if (isset($_SESSION['user_id'])) {
    // User is logged in
    $user_id = $_SESSION['user_id'];

    // Query the database to check user data
    $query = "SELECT * FROM users WHERE id = $user_id";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // User data exists in the database
        // Proceed with displaying content or performing actions
    } else {
        // User data not found in the database
        // You can prompt the user to log in again or handle it based on your requirements
        echo "User data not found. Please log in again.";
    }
} else {
    // User is not logged in
    // Handle the scenario where the session is not active
    echo "You are not logged in. Please log in to access this page.";
}
?>